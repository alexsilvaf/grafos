import { createBrowserRouter } from "react-router";
import { GraphView } from "./pages/GraphView";
import { CreateNode } from "./pages/CreateNode";
import { CreateEdge } from "./pages/CreateEdge";

export const router = createBrowserRouter([
  {
    path: "/",
    Component: GraphView,
  },
  {
    path: "/nodes/new",
    Component: CreateNode,
  },
  {
    path: "/edges/new",
    Component: CreateEdge,
  },
]);
