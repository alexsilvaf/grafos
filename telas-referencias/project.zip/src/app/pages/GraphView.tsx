import { useState, useEffect } from 'react';
import { useNavigate } from 'react-router';
import { graphService } from '../services/graphService';
import { GraphData } from '../types/graph';
import { Button } from '../components/ui/Button';
import { Card, CardContent, CardHeader } from '../components/ui/Card';
import { GraphVisualization } from '../components/GraphVisualization';
import { Alert } from '../components/ui/Alert';

type ViewState = 'loading' | 'empty' | 'loaded' | 'error' | 'render-error';

export function GraphView() {
  const navigate = useNavigate();
  const [state, setState] = useState<ViewState>('loading');
  const [graphData, setGraphData] = useState<GraphData>({ nodes: [], edges: [] });
  const [needsRefresh, setNeedsRefresh] = useState(false);
  const [renderError, setRenderError] = useState(false);

  const loadGraph = async () => {
    try {
      setState('loading');
      setRenderError(false);
      const data = await graphService.getGraph();
      setGraphData(data);

      if (data.nodes.length === 0) {
        setState('empty');
      } else {
        setState('loaded');
      }
      setNeedsRefresh(false);
    } catch (error) {
      setState('error');
    }
  };

  useEffect(() => {
    loadGraph();
  }, []);

  useEffect(() => {
    if (state === 'loaded' && graphData.nodes.length > 0) {
      try {
        // Simula verificação de renderização
        setRenderError(false);
      } catch {
        setState('render-error');
        setRenderError(true);
      }
    }
  }, [graphData, state]);

  // Check for updates from navigation state
  useEffect(() => {
    const checkForUpdates = () => {
      const shouldRefresh = sessionStorage.getItem('graph-updated');
      if (shouldRefresh === 'true') {
        setNeedsRefresh(true);
        sessionStorage.removeItem('graph-updated');
      }
    };

    checkForUpdates();
    window.addEventListener('focus', checkForUpdates);

    return () => window.removeEventListener('focus', checkForUpdates);
  }, []);

  return (
    <div className="min-h-screen bg-background">
      {/* Header */}
      <header className="border-b border-border bg-card">
        <div className="max-w-7xl mx-auto px-6 py-4">
          <div className="flex items-center justify-between">
            <div>
              <h1 className="text-foreground">Gerenciador de Grafos</h1>
              <p className="text-sm text-muted-foreground mt-1">
                Visualize e gerencie nós e arestas do seu grafo
              </p>
            </div>
            <div className="flex gap-3">
              <Button variant="secondary" onClick={() => navigate('/nodes/new')}>
                <svg className="w-4 h-4" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                  <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M12 4v16m8-8H4" />
                </svg>
                Cadastrar Nó
              </Button>
              <Button variant="primary" onClick={() => navigate('/edges/new')}>
                <svg className="w-4 h-4" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                  <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M13 7l5 5m0 0l-5 5m5-5H6" />
                </svg>
                Cadastrar Aresta
              </Button>
            </div>
          </div>
        </div>
      </header>

      {/* Main Content */}
      <main className="max-w-7xl mx-auto px-6 py-8">
        {needsRefresh && (
          <Alert type="info" onClose={() => setNeedsRefresh(false)}>
            Novos dados foram cadastrados. <button onClick={loadGraph} className="underline font-medium ml-1">Clique aqui para atualizar a visualização</button>
          </Alert>
        )}

        <div className="mt-6">
          {state === 'loading' && (
            <Card>
              <CardContent className="py-16">
                <div className="flex flex-col items-center justify-center text-center">
                  <div className="animate-spin rounded-full h-12 w-12 border-b-2 border-primary mb-4"></div>
                  <p className="text-muted-foreground">Carregando grafo...</p>
                </div>
              </CardContent>
            </Card>
          )}

          {state === 'empty' && (
            <Card>
              <CardContent className="py-16">
                <div className="flex flex-col items-center justify-center text-center max-w-md mx-auto">
                  <svg className="w-16 h-16 text-muted-foreground mb-4" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                    <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={1.5} d="M9 20l-5.447-2.724A1 1 0 013 16.382V5.618a1 1 0 011.447-.894L9 7m0 13l6-3m-6 3V7m6 10l4.553 2.276A1 1 0 0021 18.382V7.618a1 1 0 00-.553-.894L15 4m0 13V4m0 0L9 7" />
                  </svg>
                  <h3 className="text-foreground mb-2">Nenhum grafo cadastrado</h3>
                  <p className="text-muted-foreground mb-6">
                    Comece criando nós e arestas para visualizar seu grafo.
                  </p>
                  <div className="flex gap-3">
                    <Button variant="primary" onClick={() => navigate('/nodes/new')}>
                      Cadastrar Primeiro Nó
                    </Button>
                  </div>
                </div>
              </CardContent>
            </Card>
          )}

          {state === 'error' && (
            <Card>
              <CardContent className="py-16">
                <div className="flex flex-col items-center justify-center text-center max-w-md mx-auto">
                  <svg className="w-16 h-16 text-destructive mb-4" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                    <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={1.5} d="M12 8v4m0 4h.01M21 12a9 9 0 11-18 0 9 9 0 0118 0z" />
                  </svg>
                  <h3 className="text-foreground mb-2">Erro ao carregar grafo</h3>
                  <p className="text-muted-foreground mb-6">
                    Não foi possível se comunicar com a API. Verifique sua conexão e tente novamente.
                  </p>
                  <Button variant="primary" onClick={loadGraph}>
                    Tentar Novamente
                  </Button>
                </div>
              </CardContent>
            </Card>
          )}

          {state === 'render-error' && (
            <Card>
              <CardContent className="py-16">
                <div className="flex flex-col items-center justify-center text-center max-w-md mx-auto">
                  <svg className="w-16 h-16 text-destructive mb-4" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                    <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={1.5} d="M10 14l2-2m0 0l2-2m-2 2l-2-2m2 2l2 2m7-2a9 9 0 11-18 0 9 9 0 0118 0z" />
                  </svg>
                  <h3 className="text-foreground mb-2">Erro de renderização</h3>
                  <p className="text-muted-foreground mb-6">
                    Não foi possível renderizar o grafo. Os dados podem estar corrompidos.
                  </p>
                  <Button variant="primary" onClick={loadGraph}>
                    Recarregar
                  </Button>
                </div>
              </CardContent>
            </Card>
          )}

          {state === 'loaded' && !renderError && (
            <Card>
              <CardHeader>
                <div className="flex items-center justify-between">
                  <div>
                    <h2 className="text-foreground">Visualização do Grafo</h2>
                    <p className="text-sm text-muted-foreground mt-1">
                      {graphData.nodes.length} nó{graphData.nodes.length !== 1 ? 's' : ''} e {graphData.edges.length} aresta{graphData.edges.length !== 1 ? 's' : ''}
                    </p>
                  </div>
                  <Button variant="ghost" onClick={loadGraph} size="sm">
                    <svg className="w-4 h-4" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                      <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M4 4v5h.582m15.356 2A8.001 8.001 0 004.582 9m0 0H9m11 11v-5h-.581m0 0a8.003 8.003 0 01-15.357-2m15.357 2H15" />
                    </svg>
                    Atualizar
                  </Button>
                </div>
              </CardHeader>
              <CardContent>
                <div className="flex items-center justify-center">
                  <GraphVisualization data={graphData} width={900} height={600} />
                </div>
              </CardContent>
            </Card>
          )}
        </div>
      </main>
    </div>
  );
}
