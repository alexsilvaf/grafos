import { useState, FormEvent, useEffect } from 'react';
import { useNavigate } from 'react-router';
import { graphService } from '../services/graphService';
import { Node } from '../types/graph';
import { Button } from '../components/ui/Button';
import { Input } from '../components/ui/Input';
import { Select } from '../components/ui/Select';
import { Card, CardContent, CardFooter, CardHeader } from '../components/ui/Card';
import { Alert } from '../components/ui/Alert';

type FormState = 'idle' | 'loading' | 'submitting' | 'success' | 'error' | 'insufficient-nodes';
type ErrorType = 'required' | 'same-node' | 'invalid-cost' | 'exists' | 'api' | 'internal' | null;

export function CreateEdge() {
  const navigate = useNavigate();
  const [nodes, setNodes] = useState<Node[]>([]);
  const [source, setSource] = useState('');
  const [target, setTarget] = useState('');
  const [cost, setCost] = useState('');
  const [formState, setFormState] = useState<FormState>('loading');
  const [errorType, setErrorType] = useState<ErrorType>(null);
  const [successMessage, setSuccessMessage] = useState('');

  useEffect(() => {
    loadNodes();
  }, []);

  const loadNodes = async () => {
    try {
      setFormState('loading');
      const loadedNodes = await graphService.getNodes();
      setNodes(loadedNodes);

      if (loadedNodes.length < 2) {
        setFormState('insufficient-nodes');
      } else {
        setFormState('idle');
      }
    } catch (error) {
      setFormState('error');
      setErrorType('api');
    }
  };

  const resetForm = () => {
    setSource('');
    setTarget('');
    setCost('');
    setErrorType(null);
  };

  const validateForm = (): boolean => {
    if (!source || !target || !cost) {
      setErrorType('required');
      return false;
    }

    if (source === target) {
      setErrorType('same-node');
      return false;
    }

    const costNum = parseFloat(cost);
    if (isNaN(costNum) || costNum < 0) {
      setErrorType('invalid-cost');
      return false;
    }

    return true;
  };

  const handleSubmit = async (e: FormEvent, saveAnother: boolean = false) => {
    e.preventDefault();

    setErrorType(null);
    setSuccessMessage('');

    if (!validateForm()) {
      return;
    }

    setFormState('submitting');

    try {
      const costNum = parseFloat(cost);
      await graphService.createEdge(source, target, costNum);
      setFormState('success');
      setSuccessMessage(`Aresta de "${source}" para "${target}" com custo ${costNum} cadastrada com sucesso!`);

      // Mark graph as updated
      sessionStorage.setItem('graph-updated', 'true');

      if (saveAnother) {
        resetForm();
        setTimeout(() => {
          setFormState('idle');
          setSuccessMessage('');
        }, 3000);
      } else {
        setTimeout(() => {
          navigate('/');
        }, 2000);
      }
    } catch (error: any) {
      setFormState('error');

      if (error.message === 'EDGE_EXISTS') {
        setErrorType('exists');
      } else if (error.message?.includes('network') || error.message?.includes('fetch')) {
        setErrorType('api');
      } else {
        setErrorType('internal');
      }
    }
  };

  const handleCancel = () => {
    navigate('/');
  };

  if (formState === 'insufficient-nodes') {
    return (
      <div className="min-h-screen bg-background">
        <header className="border-b border-border bg-card">
          <div className="max-w-3xl mx-auto px-6 py-4">
            <div className="flex items-center gap-4">
              <button
                onClick={handleCancel}
                className="text-muted-foreground hover:text-foreground transition-colors"
              >
                <svg className="w-5 h-5" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                  <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M10 19l-7-7m0 0l7-7m-7 7h18" />
                </svg>
              </button>
              <div>
                <h1 className="text-foreground">Cadastrar Aresta</h1>
                <p className="text-sm text-muted-foreground mt-1">
                  Conecte dois nós com um custo
                </p>
              </div>
            </div>
          </div>
        </header>

        <main className="max-w-3xl mx-auto px-6 py-8">
          <Card>
            <CardContent className="py-16">
              <div className="flex flex-col items-center justify-center text-center max-w-md mx-auto">
                <svg className="w-16 h-16 text-muted-foreground mb-4" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                  <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={1.5} d="M13 16h-1v-4h-1m1-4h.01M21 12a9 9 0 11-18 0 9 9 0 0118 0z" />
                </svg>
                <h3 className="text-foreground mb-2">Nós Insuficientes</h3>
                <p className="text-muted-foreground mb-6">
                  Para cadastrar uma aresta, você precisa ter pelo menos 2 nós cadastrados. Atualmente você tem {nodes.length} nó{nodes.length !== 1 ? 's' : ''}.
                </p>
                <Button variant="primary" onClick={() => navigate('/nodes/new')}>
                  Cadastrar Nós
                </Button>
              </div>
            </CardContent>
          </Card>
        </main>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-background">
      {/* Header */}
      <header className="border-b border-border bg-card">
        <div className="max-w-3xl mx-auto px-6 py-4">
          <div className="flex items-center gap-4">
            <button
              onClick={handleCancel}
              className="text-muted-foreground hover:text-foreground transition-colors"
            >
              <svg className="w-5 h-5" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M10 19l-7-7m0 0l7-7m-7 7h18" />
              </svg>
            </button>
            <div>
              <h1 className="text-foreground">Cadastrar Aresta</h1>
              <p className="text-sm text-muted-foreground mt-1">
                Conecte dois nós com um custo
              </p>
            </div>
          </div>
        </div>
      </header>

      {/* Main Content */}
      <main className="max-w-3xl mx-auto px-6 py-8">
        {successMessage && formState === 'success' && (
          <Alert type="success" title="Sucesso" onClose={() => setSuccessMessage('')}>
            {successMessage}
          </Alert>
        )}

        {errorType === 'api' && (
          <Alert type="error" title="Erro de Comunicação">
            Não foi possível conectar à API. Verifique sua conexão e tente novamente.
          </Alert>
        )}

        {errorType === 'internal' && (
          <Alert type="error" title="Erro Interno">
            Ocorreu um erro na camada de processamento. Tente novamente mais tarde.
          </Alert>
        )}

        {formState === 'loading' ? (
          <Card>
            <CardContent className="py-16">
              <div className="flex flex-col items-center justify-center text-center">
                <div className="animate-spin rounded-full h-12 w-12 border-b-2 border-primary mb-4"></div>
                <p className="text-muted-foreground">Carregando nós disponíveis...</p>
              </div>
            </CardContent>
          </Card>
        ) : (
          <Card className="mt-6">
            <CardHeader>
              <h2 className="text-foreground">Informações da Aresta</h2>
              <p className="text-sm text-muted-foreground mt-1">
                Selecione os nós de origem e destino, e defina o custo
              </p>
            </CardHeader>

            <form onSubmit={(e) => handleSubmit(e, false)}>
              <CardContent className="space-y-4">
                <Select
                  label="Nó de Origem"
                  options={nodes.map(n => ({ value: n.id, label: n.label }))}
                  value={source}
                  onChange={(e) => {
                    setSource(e.target.value);
                    setErrorType(null);
                  }}
                  placeholder="Selecione o nó de origem"
                  error={errorType === 'required' && !source ? 'Selecione um nó de origem' : undefined}
                  required
                  disabled={formState === 'submitting'}
                />

                <Select
                  label="Nó de Destino"
                  options={nodes.map(n => ({ value: n.id, label: n.label }))}
                  value={target}
                  onChange={(e) => {
                    setTarget(e.target.value);
                    setErrorType(null);
                  }}
                  placeholder="Selecione o nó de destino"
                  error={
                    errorType === 'required' && !target
                      ? 'Selecione um nó de destino'
                      : errorType === 'same-node'
                      ? 'Os nós de origem e destino devem ser diferentes'
                      : undefined
                  }
                  required
                  disabled={formState === 'submitting'}
                />

                <Input
                  label="Custo"
                  type="number"
                  step="0.01"
                  min="0"
                  placeholder="Ex: 10, 5.5, 100"
                  value={cost}
                  onChange={(e) => {
                    setCost(e.target.value);
                    setErrorType(null);
                  }}
                  error={
                    errorType === 'required' && !cost
                      ? 'O custo é obrigatório'
                      : errorType === 'invalid-cost'
                      ? 'Digite um valor numérico válido maior ou igual a zero'
                      : errorType === 'exists'
                      ? 'Esta aresta já existe'
                      : undefined
                  }
                  helperText="Valor numérico que representa o peso da conexão"
                  required
                  disabled={formState === 'submitting'}
                />
              </CardContent>

              <CardFooter className="border-t border-border justify-end">
                <Button
                  type="button"
                  variant="ghost"
                  onClick={handleCancel}
                  disabled={formState === 'submitting'}
                >
                  Cancelar
                </Button>
                <Button
                  type="button"
                  variant="secondary"
                  onClick={(e) => handleSubmit(e, true)}
                  disabled={formState === 'submitting' || !source || !target || !cost}
                >
                  {formState === 'submitting' ? 'Salvando...' : 'Salvar e Cadastrar Outra'}
                </Button>
                <Button
                  type="submit"
                  variant="primary"
                  disabled={formState === 'submitting' || !source || !target || !cost}
                >
                  {formState === 'submitting' ? (
                    <>
                      <div className="animate-spin rounded-full h-4 w-4 border-b-2 border-white"></div>
                      Salvando...
                    </>
                  ) : (
                    'Salvar'
                  )}
                </Button>
              </CardFooter>
            </form>
          </Card>
        )}
      </main>
    </div>
  );
}
