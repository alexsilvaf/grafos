import { useState, FormEvent } from 'react';
import { useNavigate } from 'react-router';
import { graphService } from '../services/graphService';
import { Button } from '../components/ui/Button';
import { Input } from '../components/ui/Input';
import { Card, CardContent, CardFooter, CardHeader } from '../components/ui/Card';
import { Alert } from '../components/ui/Alert';

type FormState = 'idle' | 'submitting' | 'success' | 'error';
type ErrorType = 'required' | 'exists' | 'api' | 'internal' | null;

export function CreateNode() {
  const navigate = useNavigate();
  const [identifier, setIdentifier] = useState('');
  const [formState, setFormState] = useState<FormState>('idle');
  const [errorType, setErrorType] = useState<ErrorType>(null);
  const [successMessage, setSuccessMessage] = useState('');

  const resetForm = () => {
    setIdentifier('');
    setErrorType(null);
  };

  const validateForm = (): boolean => {
    if (!identifier.trim()) {
      setErrorType('required');
      return false;
    }
    return true;
  };

  const handleSubmit = async (e: FormEvent, saveAnother: boolean = false) => {
    e.preventDefault();

    setErrorType(null);
    setSuccessMessage('');

    if (!validateForm()) {
      return;
    }

    setFormState('submitting');

    try {
      await graphService.createNode(identifier.trim());
      setFormState('success');
      setSuccessMessage(`Nó "${identifier}" cadastrado com sucesso!`);

      // Mark graph as updated
      sessionStorage.setItem('graph-updated', 'true');

      if (saveAnother) {
        resetForm();
        setTimeout(() => {
          setFormState('idle');
          setSuccessMessage('');
        }, 3000);
      } else {
        setTimeout(() => {
          navigate('/');
        }, 2000);
      }
    } catch (error: any) {
      setFormState('error');

      if (error.message === 'NODE_EXISTS') {
        setErrorType('exists');
      } else if (error.message?.includes('network') || error.message?.includes('fetch')) {
        setErrorType('api');
      } else {
        setErrorType('internal');
      }
    }
  };

  const handleCancel = () => {
    navigate('/');
  };

  return (
    <div className="min-h-screen bg-background">
      {/* Header */}
      <header className="border-b border-border bg-card">
        <div className="max-w-3xl mx-auto px-6 py-4">
          <div className="flex items-center gap-4">
            <button
              onClick={handleCancel}
              className="text-muted-foreground hover:text-foreground transition-colors"
            >
              <svg className="w-5 h-5" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M10 19l-7-7m0 0l7-7m-7 7h18" />
              </svg>
            </button>
            <div>
              <h1 className="text-foreground">Cadastrar Nó</h1>
              <p className="text-sm text-muted-foreground mt-1">
                Adicione um novo nó ao grafo
              </p>
            </div>
          </div>
        </div>
      </header>

      {/* Main Content */}
      <main className="max-w-3xl mx-auto px-6 py-8">
        {successMessage && formState === 'success' && (
          <Alert type="success" title="Sucesso" onClose={() => setSuccessMessage('')}>
            {successMessage}
          </Alert>
        )}

        {errorType === 'api' && (
          <Alert type="error" title="Erro de Comunicação">
            Não foi possível conectar à API. Verifique sua conexão e tente novamente.
          </Alert>
        )}

        {errorType === 'internal' && (
          <Alert type="error" title="Erro Interno">
            Ocorreu um erro na camada de processamento. Tente novamente mais tarde.
          </Alert>
        )}

        <Card className="mt-6">
          <CardHeader>
            <h2 className="text-foreground">Informações do Nó</h2>
            <p className="text-sm text-muted-foreground mt-1">
              Preencha o identificador único para o novo nó
            </p>
          </CardHeader>

          <form onSubmit={(e) => handleSubmit(e, false)}>
            <CardContent>
              <Input
                label="Identificador do Nó"
                placeholder="Ex: A, B, Node1, etc."
                value={identifier}
                onChange={(e) => {
                  setIdentifier(e.target.value);
                  setErrorType(null);
                }}
                error={
                  errorType === 'required'
                    ? 'O identificador é obrigatório'
                    : errorType === 'exists'
                    ? 'Este identificador já existe'
                    : undefined
                }
                helperText="Use um nome único e descritivo"
                required
                disabled={formState === 'submitting'}
                autoFocus
              />
            </CardContent>

            <CardFooter className="border-t border-border justify-end">
              <Button
                type="button"
                variant="ghost"
                onClick={handleCancel}
                disabled={formState === 'submitting'}
              >
                Cancelar
              </Button>
              <Button
                type="button"
                variant="secondary"
                onClick={(e) => handleSubmit(e, true)}
                disabled={formState === 'submitting' || !identifier.trim()}
              >
                {formState === 'submitting' ? 'Salvando...' : 'Salvar e Cadastrar Outro'}
              </Button>
              <Button
                type="submit"
                variant="primary"
                disabled={formState === 'submitting' || !identifier.trim()}
              >
                {formState === 'submitting' ? (
                  <>
                    <div className="animate-spin rounded-full h-4 w-4 border-b-2 border-white"></div>
                    Salvando...
                  </>
                ) : (
                  'Salvar'
                )}
              </Button>
            </CardFooter>
          </form>
        </Card>
      </main>
    </div>
  );
}
