import { Node, Edge, GraphData } from '../types/graph';

// Simulação de armazenamento local (substitua por chamadas de API reais)
class GraphService {
  private storageKey = 'graph-manager-data';

  private getData(): GraphData {
    const stored = localStorage.getItem(this.storageKey);
    return stored ? JSON.parse(stored) : { nodes: [], edges: [] };
  }

  private saveData(data: GraphData): void {
    localStorage.setItem(this.storageKey, JSON.stringify(data));
  }

  // Nodes
  async getNodes(): Promise<Node[]> {
    // Simula delay de API
    await new Promise(resolve => setTimeout(resolve, 300));
    return this.getData().nodes;
  }

  async createNode(identifier: string): Promise<Node> {
    await new Promise(resolve => setTimeout(resolve, 400));

    const data = this.getData();

    // Verifica se já existe
    if (data.nodes.some(n => n.id === identifier)) {
      throw new Error('NODE_EXISTS');
    }

    const newNode: Node = {
      id: identifier,
      label: identifier
    };

    data.nodes.push(newNode);
    this.saveData(data);

    return newNode;
  }

  async deleteNode(id: string): Promise<void> {
    await new Promise(resolve => setTimeout(resolve, 300));

    const data = this.getData();
    data.nodes = data.nodes.filter(n => n.id !== id);
    data.edges = data.edges.filter(e => e.source !== id && e.target !== id);
    this.saveData(data);
  }

  // Edges
  async getEdges(): Promise<Edge[]> {
    await new Promise(resolve => setTimeout(resolve, 300));
    return this.getData().edges;
  }

  async createEdge(source: string, target: string, cost: number): Promise<Edge> {
    await new Promise(resolve => setTimeout(resolve, 400));

    const data = this.getData();

    // Verifica se a aresta já existe
    if (data.edges.some(e => e.source === source && e.target === target)) {
      throw new Error('EDGE_EXISTS');
    }

    const newEdge: Edge = {
      id: `${source}-${target}`,
      source,
      target,
      cost
    };

    data.edges.push(newEdge);
    this.saveData(data);

    return newEdge;
  }

  async deleteEdge(id: string): Promise<void> {
    await new Promise(resolve => setTimeout(resolve, 300));

    const data = this.getData();
    data.edges = data.edges.filter(e => e.id !== id);
    this.saveData(data);
  }

  // Graph
  async getGraph(): Promise<GraphData> {
    await new Promise(resolve => setTimeout(resolve, 300));
    return this.getData();
  }
}

export const graphService = new GraphService();
