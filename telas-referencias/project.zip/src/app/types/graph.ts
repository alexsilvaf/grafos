export interface Node {
  id: string;
  label: string;
}

export interface Edge {
  id: string;
  source: string;
  target: string;
  cost: number;
}

export interface GraphData {
  nodes: Node[];
  edges: Edge[];
}
